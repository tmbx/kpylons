from bel.apps.feed import feed
FeedControllerBase = feed.FeedControllerBase
