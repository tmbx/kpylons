This directory is required by the default setting:

rdfalchemy.dburi = sqlite:///%(here)s/data/graph

Otherwise it can be deleted.
